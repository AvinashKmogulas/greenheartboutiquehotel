<?php
//$request_url=str_replace('','',$_SERVER['REQUEST_URI']);
$request_url=$_SERVER['REQUEST_URI'];
if ($request_url == '/') {
	$metatitle = "Hotel in Paramaribo, Suriname - Greenheart Boutique Hotel";
    $metadesc = "One of the best hotels in Paramaribo, Suriname - Greenheart boutique Hotel offers all kinds of modern amenities with world-class accommodations, which feel like a home away from home. Enquire Now.";
	$keywords = "Hotels in Paramaribo, Hotel in Suriname";	} 
elseif ($request_url == '/history.php') {
	$metatitle = "Hotel in Paramaribo, Suriname - Greenheart Boutique Hotel";
    $metadesc = "Greenheart boutique hotel was a ruined stone structure before, but now the hotel is designed with Surinamese woods, which looks exquisite. Best eco-friendly hotel in Paramaribo, Visit Now!.";
	$keywords = "Hotel in Paramaribo, Hotel in Suriname, nature resorts in suriname";
	}
elseif ($request_url == '/rooms.php') {
	$metatitle = "Hotel Rooms in Paramaribo | Greenheart Boutique Hotel";
    $metadesc = "Greenheart Boutique Hotel has the best hotel rooms in Paramaribo. It consists of eco-friendly & spacious accommodations with private terraces to spend your leisure time amidst the greenery. Book your room now!.";
	$keywords = "eco resort Suriname, best hotel in Paramaribo, hotel booking Paramaribo";
}
elseif ($request_url == '/dine.php') {
	$metatitle = "Paramaribo Restaurants - Greenheart Boutique Hotel";
    $metadesc = "Are you looking for cafe options in Paramaribo? Taste the local & international cuisine at the best Paramaribo restaurant by GreenHeart Boutique Hotel. Reserve your table now!";
	$keywords = "paramaribo restaurants, Fine dining in Paramaribo, restaurants in Paramaribo";
}
elseif ($request_url == '/service-and-facilities.php') {
	$metatitle = "Best Hotels in Suriname - Greenheart Boutique Hotel";
    $metadesc = " We try to fulfil all your needs in one place with the best amenities & facilities like a swimming pool, restaurant, library and much more for the best Experience at Hotel in Suriname - Greenheart Boutique Hotel, Book Now!";
	$keywords = "hotels near Waterkant Paramaribo, Suriname all inclusive resorts, hotel with swimming pool in Suriname";
}
elseif ($request_url == '/nature-packages.php') {
	$metatitle = "Nature Resorts in Suriname - Greenheart Boutique Hotel";
    $metadesc = "This vacation, treat yourself to a wide range of luxurious, modern and eco-friendly accommodation options at one of the best eco Resorts in Paramaribo - Greenheart Boutique Hotel, Book Now!";
	$keywords = "best hotels in suriname, eco resort suriname, hotel in paramaribo, hotels paramaribo";
}
elseif ($request_url == '/gallery.php') {
	$metatitle = "Hotel in Paramaribo, Suriname | Gallery - Greenheart Boutique Hotel";
    $metadesc = "Explore the gallery of one of the best hotels in Paramaribo, Suriname. Check out the luxurious amenities, facilities & warm hospitality of Greenheart Boutique Hotel, Book Now.";
	$keywords = "Photos of hotel in Paramaribo, hotel in Paramaribo, hotel in Suriname";
}
elseif ($request_url == '/contact.php') {
	$metatitle = "Hotel Booking Paramaribo | Contact Us - Greenheart Boutique Hotel";
    $metadesc = "For the best hotel in Paramaribo, Suriname Greenheart Boutique Hotel is the right place to experience an Ecofriendly stay in Paramaribo. To enjoy your memorable time with us, Contact us Now!";
	$keywords = "hotel in paramaribo, best hotel in Paramaribo, eco resort suriname, hotels in paramaribo suriname";
}
?>
